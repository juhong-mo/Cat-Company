using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class LayerSettings : MonoBehaviour
{
    //Set from gameObject
    public LayerMask layerAlly;
    public LayerMask layerEnemy;
}